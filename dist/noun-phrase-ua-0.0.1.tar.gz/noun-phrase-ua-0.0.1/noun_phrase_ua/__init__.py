from .nlp import NLP

name = "noun_phrase_ua"
