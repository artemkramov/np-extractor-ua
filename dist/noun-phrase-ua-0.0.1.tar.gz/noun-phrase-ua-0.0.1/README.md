# Python package to extract NP from the Ukrainian language

This is a simple package to extract noun phrases from a raw Ukrainian text.