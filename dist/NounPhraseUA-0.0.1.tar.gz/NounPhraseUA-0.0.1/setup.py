import setuptools

setuptools.setup(
    name='NounPhraseUA',
    version='0.0.1',
    packages=setuptools.find_packages(),
    author='artemkramov',
    author_email='artemkramov@gmail.com',
    description='Noun phrase extractor for the Ukrainian language'
)
